/*
 * Hello Minecraft! Launcher
 * Copyright (C) 2021  huangyuhui <huanghongxun2008@126.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.jackhuang.hmcl.auth;

public abstract class ClassicAccount extends Account {
    /// Creates a classic account.
    ///
    /// @param accountID the stable account entry ID
    protected ClassicAccount(AccountID accountID) {
        super(accountID);
    }

    /**
     * @return the login name used by the remote authentication service
     */
    public abstract String getLoginName();

    /**
     * Login with specified password.
     *
     * When credentials expired, the auth server will ask you to login with password to refresh
     * credentials.
     */
    public abstract AuthInfo logInWithPassword(String password) throws AuthenticationException;
}
