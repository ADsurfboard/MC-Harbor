/*
 * Hello Minecraft! Launcher
 * Copyright (C) 2026 huangyuhui <huanghongxun2008@126.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.jackhuang.hmcl.addon.resourcepack;

import com.google.gson.annotations.SerializedName;
import org.jackhuang.hmcl.game.GameRepository;
import org.jackhuang.hmcl.addon.LocalAddonManager;
import org.jackhuang.hmcl.addon.meta.PackMcMeta;
import org.jackhuang.hmcl.util.Pair;
import org.jackhuang.hmcl.util.StringUtils;
import org.jackhuang.hmcl.util.gson.JsonSerializable;
import org.jackhuang.hmcl.util.gson.JsonUtils;
import org.jackhuang.hmcl.util.io.CompressingUtils;
import org.jackhuang.hmcl.util.io.FileUtils;
import org.jackhuang.hmcl.util.tree.ZipFileTree;
import org.jackhuang.hmcl.util.versioning.GameVersionNumber;
import org.jackhuang.hmcl.util.versioning.VersionRange;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

import static org.jackhuang.hmcl.util.logging.Logger.LOG;

public final class ResourcePackManager extends LocalAddonManager<ResourcePackFile> {

    private static final List<String> RESOURCE_PACK_VERSION_OLD = List.of(
            "13w24a", // 1
            "15w31a", // 2
            "16w32a", // 3
            "17w48a", // 4
            "18w47b"  // 5
    );

    public static final String LEAST_MC_VERSION_RELEASE = "1.6.1";
    public static final String LEAST_MC_VERSION_SNAPSHOT = "13w24a";
    public static final String LEAST_MC_VERSION_NEW_OPTIONS_RELEASE = "1.13";
    public static final String LEAST_MC_VERSION_NEW_OPTIONS_SNAPSHOT = "17w43a";

    public static boolean isMcVersionSupported(@NotNull GameVersionNumber version) {
        return version.isAtLeast(LEAST_MC_VERSION_RELEASE, LEAST_MC_VERSION_SNAPSHOT);
    }

    public static boolean isMcVersionSupportsNewOptionsFormat(@NotNull GameVersionNumber version) {
        return version.isAtLeast(LEAST_MC_VERSION_NEW_OPTIONS_RELEASE, LEAST_MC_VERSION_NEW_OPTIONS_SNAPSHOT);
    }

    @NotNull
    public static PackMcMeta.PackVersion getPackVersion(GameVersionNumber minecraftVersion, Path gameJar) {
        for (int i = 0; i < RESOURCE_PACK_VERSION_OLD.size(); i++) {
            if (minecraftVersion.compareTo(RESOURCE_PACK_VERSION_OLD.get(i)) < 0) {
                return i == 0 ? PackMcMeta.PackVersion.UNSPECIFIED : new PackMcMeta.PackVersion(i, 0);
            }
        }
        try (var zipFileTree = new ZipFileTree(CompressingUtils.openZipFile(gameJar))) {
            String versionJson = zipFileTree.readTextEntry("/version.json");
            try {
                var info = JsonUtils.fromNonNullJson(versionJson, GameVersionInfo117.class).packVersionInfo();
                if (info.resourceMajor() > 64) {
                    return new PackMcMeta.PackVersion(info.resourceMajor(), info.resourceMinor());
                } else {
                    return new PackMcMeta.PackVersion(info.resource(), 0);
                }
            } catch (Exception e) {
                LOG.warning("Failed to load Minecraft resource pack version for 25w31a+", e);
            }
            try {
                return new PackMcMeta.PackVersion(JsonUtils.fromNonNullJson(versionJson, GameVersionInfo114.class).packVersion, 0);
            } catch (Exception e) {
                LOG.warning("Failed to load Minecraft resource pack version for 18w47b+", e);
            }
            return PackMcMeta.PackVersion.UNSPECIFIED;
        } catch (Exception e) {
            LOG.error("Failed to load Minecraft resource pack version", e);
            return PackMcMeta.PackVersion.UNSPECIFIED;
        }
    }

    @NotNull
    @Contract(pure = true)
    public static VersionRange<PackMcMeta.PackVersion> getResourcePackVersionRangeOldest(PackMcMeta.PackInfo packInfo) {
        if (packInfo == null || packInfo.packFormat() <= 0)
            return VersionRange.empty();
        else
            return VersionRange.is(new PackMcMeta.PackVersion(packInfo.packFormat(), 0));
    }

    @NotNull
    @Contract(pure = true)
    public static VersionRange<PackMcMeta.PackVersion> getResourcePackVersionRangeOld(PackMcMeta.PackInfo packInfo) {
        if (packInfo == null)
            return VersionRange.empty();
        if (packInfo.packFormat() <= 0)
            return VersionRange.empty();
        if (packInfo.supportedFormats().isUnspecified()) {
            return VersionRange.is(new PackMcMeta.PackVersion(packInfo.packFormat(), 0));
        }
        return VersionRange.between(packInfo.supportedFormats().getMin(), packInfo.supportedFormats().getMax());
    }

    @NotNull
    @Contract(pure = true)
    public static VersionRange<PackMcMeta.PackVersion> getResourcePackVersionRangeNew(PackMcMeta.PackInfo packInfo) {
        if (packInfo == null)
            return VersionRange.empty();

        boolean packFormatUnspecified = packInfo.packFormat() <= 0;
        boolean supportedFormatsUnspecified = packInfo.supportedFormats().isUnspecified();

        // See https://zh.minecraft.wiki/w/Pack.mcmeta
        // Also referring to Minecraft's source code
        if (packInfo.minPackVersion().isUnspecified() || packInfo.maxPackVersion().isUnspecified()) { // Old format
            if (!supportedFormatsUnspecified) {
                PackMcMeta.SupportedFormats supportedFormats = packInfo.supportedFormats();
                int min = supportedFormats.min();
                int max = supportedFormats.max();
                if (max > 64) {
                    return VersionRange.empty();
                } else {
                    if (packFormatUnspecified)
                        return VersionRange.empty();
                    if (isPackFormatInvalid(min, max, packInfo.packFormat()))
                        return VersionRange.empty();
                }

                return VersionRange.between(supportedFormats.getMin(), supportedFormats.getMax());
            } else if (!packFormatUnspecified) {
                int packFormat = packInfo.packFormat();
                PackMcMeta.PackVersion packVersion = new PackMcMeta.PackVersion(packFormat, 0);
                return packFormat > 64 ? VersionRange.empty() : VersionRange.is(packVersion);
            }
        } else { // New format
            int minMajor = packInfo.minPackVersion().majorVersion();
            int maxMajor = packInfo.maxPackVersion().majorVersion();
            if (packInfo.minPackVersion().compareTo(packInfo.maxPackVersion()) > 0) {
                return VersionRange.empty();
            }
            if (minMajor > 64) {
                if (!supportedFormatsUnspecified)
                    return VersionRange.empty();

                if (!packFormatUnspecified && isPackFormatInvalid(minMajor, maxMajor, packInfo.packFormat()))
                    return VersionRange.empty();
            } else {
                if (supportedFormatsUnspecified)
                    return VersionRange.empty();
                PackMcMeta.SupportedFormats supportedFormats = packInfo.supportedFormats();
                if (supportedFormats.min() != minMajor)
                    return VersionRange.empty();
                if (supportedFormats.max() != maxMajor && supportedFormats.max() != 64)
                    return VersionRange.empty();
                if (packFormatUnspecified)
                    return VersionRange.empty();
                if (isPackFormatInvalid(minMajor, maxMajor, packInfo.packFormat()))
                    return VersionRange.empty();
            }

            return VersionRange.between(packInfo.minPackVersion(), packInfo.maxPackVersion());
        }
        return VersionRange.empty();
    }

    @Contract(pure = true)
    private static boolean isPackFormatInvalid(int i, int j, int k) {
        if (k >= i && k <= j) {
            return k < 15;
        } else {
            return true;
        }
    }

    private static String serializePackList(List<String> packNames) {
        try {
            return StringUtils.serializeStringList(packNames);
        } catch (Exception e) {
            LOG.warning("Failed to serialize resource pack list: \n" + packNames, e);
            return "[]";
        }
    }

    private static List<String> deserializePackList(String json) {
        try {
            return StringUtils.deserializeStringList(json);
        } catch (Exception e) {
            LOG.warning("Failed to deserialize resource pack list: \n" + json, e);
            return List.of();
        }
    }


    private final Path resourcePackDirectory;
    private final Path optionsFile;

    private @Nullable GameVersionNumber minecraftVersion;
    private @Nullable PackMcMeta.PackVersion requiredVersion;
    private boolean supportsNewOptionsFormat;

    private boolean loaded = false;

    public ResourcePackManager(GameRepository repository, String id) {
        super(repository, id);
        this.resourcePackDirectory = this.repository.getResourcePackDirectory(this.id);
        this.optionsFile = repository.getRunDirectory(id).resolve("options.txt");
    }

    @NotNull
    private Map<String, String> loadOptions() {
        getMinecraftVersion();
        Map<String, String> options = new LinkedHashMap<>();
        if (!Files.isRegularFile(optionsFile)) return options;
        try (var stream = Files.lines(optionsFile, StandardCharsets.UTF_8)) {
            stream.forEach(s -> {
                if (StringUtils.isNotBlank(s)) {
                    var entry = s.split(":", 2);
                    if (entry.length == 2) {
                        options.put(entry[0], entry[1]);
                    }
                }
            });
        } catch (IOException e) {
            LOG.warning("Failed to read instance options file", e);
        }
        return options;
    }

    private void saveOptions(@NotNull Map<String, String> options) {
        try {
            StringBuilder sb = new StringBuilder();
            for (var entry : options.entrySet()) {
                sb.append(entry.getKey()).append(":").append(entry.getValue()).append(System.lineSeparator());
            }
            FileUtils.saveSafely(optionsFile, sb.toString());
        } catch (IOException e) {
            LOG.warning("Failed to save instance options file", e);
        }
    }

    @NotNull
    public GameVersionNumber getMinecraftVersion() {
        if (minecraftVersion == null) {
            lock.lock();
            try {
                if (minecraftVersion == null) {
                    minecraftVersion = GameVersionNumber.asGameVersion(repository.getGameVersion(id));
                    supportsNewOptionsFormat = isMcVersionSupportsNewOptionsFormat(minecraftVersion);
                }
            } finally {
                lock.unlock();
            }
        }
        return minecraftVersion;
    }

    @NotNull
    public PackMcMeta.PackVersion getRequiredVersion() {
        if (requiredVersion == null) {
            lock.lock();
            try {
                if (requiredVersion == null) requiredVersion = getPackVersion(getMinecraftVersion(), repository.getVersionJar(id));
            } finally {
                lock.unlock();
            }
        }
        return requiredVersion;
    }

    @Override
    public Path getDirectory() {
        return resourcePackDirectory;
    }

    private void addResourcePackInfo(Path file) throws IOException {
        ResourcePackFile resourcePack = ResourcePackFile.fromFile(this, file);
        if (resourcePack != null) localFiles.add(resourcePack);
    }

    @Override
    public void refresh() throws IOException {
        lock.lock();
        try {
            localFiles.clear();

            if (Files.isDirectory(resourcePackDirectory)) {
                try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(resourcePackDirectory)) {
                    for (Path subitem : directoryStream) {
                        try {
                            addResourcePackInfo(subitem);
                        } catch (IOException e) {
                            LOG.warning("Failed to load resource pack " + subitem, e);
                        }
                    }
                }
            }
            loaded = true;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public Comparator<ResourcePackFile> getComparator() {
        return ResourcePackFile::compareTo;
    }

    @Override
    public @Unmodifiable List<ResourcePackFile> getLocalFiles() throws IOException {
        lock.lock();
        try {
            if (!loaded)
                refresh();
            return super.getLocalFiles();
        } finally {
            lock.unlock();
        }
    }

    public void importResourcePack(Path file) throws IOException, IllegalArgumentException {
        lock.lock();
        try {
            if (ResourcePackFile.isFileResourcePack(file)) {
                if (!loaded)
                    refresh();
                Files.createDirectories(resourcePackDirectory);

                Path newFile = resourcePackDirectory.resolve(file.getFileName());
                if (Files.isDirectory(file)) {
                    FileUtils.copyDirectory(file, newFile);
                } else {
                    FileUtils.copyFile(file, newFile);
                }

                addResourcePackInfo(newFile);
            } else {
                throw new IllegalArgumentException("File '" + file + "' is not a resource pack");
            }
        } finally {
            lock.unlock();
        }
    }

    public boolean removeResourcePacks(List<ResourcePackFile> resourcePacks) throws IOException {
        lock.lock();
        try {
            boolean modified = disableResourcePacks(resourcePacks);
            for (ResourcePackFile resourcePack : resourcePacks) {
                if (resourcePack != null && resourcePack.manager == this) {
                    resourcePack.delete();
                    localFiles.remove(resourcePack);
                    modified = true;
                }
            }
            return modified;
        } finally {
            lock.unlock();
        }
    }

    private boolean containsResourcePack(List<String> resourcePacks, String packIdOld) {
        String packId = "file/" + packIdOld;
        if (supportsNewOptionsFormat) return resourcePacks.contains(packIdOld) || resourcePacks.contains(packId);
        return resourcePacks.contains(packIdOld);
    }

    public boolean enableResourcePacks(List<ResourcePackFile> resourcePackFiles) {
        lock.lock();
        try {
            boolean modified = false;
            Map<String, String> options = loadOptions();
            List<String> resourcePacks = new ArrayList<>(deserializePackList(options.get("resourcePacks")));
            List<String> incompatibleResourcePacks = new ArrayList<>(deserializePackList(options.get("incompatibleResourcePacks")));
            for (var pack : resourcePackFiles) {
                if (enableResourcePack(pack, resourcePacks, incompatibleResourcePacks)) modified = true;
            }
            if (modified) {
                options.put("resourcePacks", serializePackList(resourcePacks));
                options.put("incompatibleResourcePacks", serializePackList(incompatibleResourcePacks));
                saveOptions(options);
            }
            return modified;
        } finally {
            lock.unlock();
        }
    }

    private boolean enableResourcePack(ResourcePackFile resourcePack, List<String> resourcePacks, List<String> incompatibleResourcePacks) {
        if (resourcePack.manager != this) return false;
        String packId = "file/" + resourcePack.getFileNameWithExtension();
        String packIdOld = resourcePack.getFileNameWithExtension();
        boolean modified = false;
        if (!containsResourcePack(resourcePacks, packIdOld)) {
            resourcePacks.add(supportsNewOptionsFormat ? packId : packIdOld);
            modified = true;
        }
        boolean incompatibleContains = containsResourcePack(incompatibleResourcePacks, packIdOld);
        boolean incompatible = isIncompatible(resourcePack);
        if (!incompatibleContains && incompatible) {
            incompatibleResourcePacks.add(supportsNewOptionsFormat ? packId : packIdOld);
            modified = true;
        } else if (incompatibleContains && !incompatible) {
            incompatibleResourcePacks.removeAll(List.of(packId));
            incompatibleResourcePacks.removeAll(List.of(packIdOld));
            modified = true;
        }
        return modified;
    }

    public boolean disableResourcePacks(List<ResourcePackFile> resourcePackFiles) {
        lock.lock();
        try {
            boolean modified = false;
            Map<String, String> options = loadOptions();
            List<String> resourcePacks = new ArrayList<>(deserializePackList(options.get("resourcePacks")));
            List<String> incompatibleResourcePacks = new ArrayList<>(deserializePackList(options.get("incompatibleResourcePacks")));
            for (var pack : resourcePackFiles) {
                if (disableResourcePack(pack, resourcePacks, incompatibleResourcePacks)) modified = true;
            }
            if (modified) {
                options.put("resourcePacks", serializePackList(resourcePacks));
                options.put("incompatibleResourcePacks", serializePackList(incompatibleResourcePacks));
                saveOptions(options);
            }
            return modified;
        } finally {
            lock.unlock();
        }
    }

    private boolean disableResourcePack(ResourcePackFile resourcePack, List<String> resourcePacks, List<String> incompatibleResourcePacks) {
        if (resourcePack.manager != this) return false;
        String packId = "file/" + resourcePack.getFileNameWithExtension();
        String packIdOld = resourcePack.getFileNameWithExtension();
        boolean modified = false;
        if (resourcePacks.contains(packId)) {
            resourcePacks.removeAll(List.of(packId));
            modified = true;
        }
        if (resourcePacks.contains(packIdOld)) {
            resourcePacks.removeAll(List.of(packIdOld));
            modified = true;
        }
        if (incompatibleResourcePacks.contains(packId)) {
            incompatibleResourcePacks.removeAll(List.of(packId));
            modified = true;
        }
        if (incompatibleResourcePacks.contains(packIdOld)) {
            incompatibleResourcePacks.removeAll(List.of(packIdOld));
            modified = true;
        }
        return modified;
    }

    private boolean isEnabled(ResourcePackFile pack, List<String> optPacks, List<String> optIncompatiblePacks) {
        if (pack.manager != this) return false;
        String packIdOld = pack.getFileNameWithExtension();
        if (!containsResourcePack(optPacks, packIdOld)) return false;
        return isIncompatible(pack) == containsResourcePack(optIncompatiblePacks, packIdOld);
    }

    public boolean isEnabled(ResourcePackFile resourcePack) {
        lock.lock();
        try {
            Map<String, String> options = loadOptions();
            List<String> optPacks = deserializePackList(options.get("resourcePacks"));
            List<String> optIncompatiblePacks = deserializePackList(options.get("incompatibleResourcePacks"));
            return isEnabled(resourcePack, optPacks, optIncompatiblePacks);
        } finally {
            lock.unlock();
        }
    }

    public Stream<Pair<ResourcePackFile, Boolean>> arePacksEnabled(Stream<ResourcePackFile> resourcePacks) {
        lock.lock();
        try {
            Map<String, String> options = loadOptions();
            List<String> optPacks = deserializePackList(options.get("resourcePacks"));
            List<String> optIncompatiblePacks = deserializePackList(options.get("incompatibleResourcePacks"));
            return resourcePacks.map(pack -> Pair.pair(pack, isEnabled(pack, optPacks, optIncompatiblePacks)));
        } finally {
            lock.unlock();
        }
    }

    public ResourcePackFile.Compatibility getCompatibility(@NotNull ResourcePackFile resourcePack) {
        if (resourcePack.getMeta() == null || resourcePack.getMeta().pack() == null)
            return ResourcePackFile.Compatibility.MISSING_PACK_META;
        if (this.getRequiredVersion().isUnspecified())
            return ResourcePackFile.Compatibility.MISSING_GAME_META;
        int requiredMajor = getRequiredVersion().majorVersion();
        VersionRange<PackMcMeta.PackVersion> versionRange;
        if (requiredMajor > 64)
            versionRange = getResourcePackVersionRangeNew(resourcePack.getMeta().pack());
        else if (requiredMajor > 15)
            versionRange = getResourcePackVersionRangeOld(resourcePack.getMeta().pack());
        else
            versionRange = getResourcePackVersionRangeOldest(resourcePack.getMeta().pack());
        if (versionRange.isEmpty())
            return ResourcePackFile.Compatibility.INVALID;
        if (versionRange.getMaximum().compareTo(this.getRequiredVersion()) < 0)
            return ResourcePackFile.Compatibility.TOO_OLD;
        if (versionRange.getMinimum().compareTo(this.getRequiredVersion()) > 0)
            return ResourcePackFile.Compatibility.TOO_NEW;
        return ResourcePackFile.Compatibility.COMPATIBLE;
    }

    public boolean isIncompatible(@NotNull ResourcePackFile resourcePack) {
        return getCompatibility(resourcePack) != ResourcePackFile.Compatibility.COMPATIBLE;
    }

    @JsonSerializable
    private record GameVersionInfo114(@SerializedName("pack_version") int packVersion) {
    }

    @JsonSerializable
    private record GameVersionInfo117(@SerializedName("pack_version") PackVersionInfo117 packVersionInfo) {
    }

    @JsonSerializable
    private record PackVersionInfo117(int resource,
                                      @SerializedName("resource_major") int resourceMajor,
                                      @SerializedName("resource_minor") int resourceMinor) {
    }
}
